package storelocator.br.com.storelocator.network.serviceBuilder;

public interface MyResponse {
}
